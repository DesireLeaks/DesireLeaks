(() => {
  const gate = document.getElementById("ageGate");
  const enter = document.getElementById("enterBtn");
  const leave = document.getElementById("leaveBtn");

  if (localStorage.getItem("dd_age_ok") === "1") {
    gate.classList.add("hidden");
  }

  enter.addEventListener("click", () => {
    localStorage.setItem("dd_age_ok", "1");
    gate.classList.add("hidden");
  });

  leave.addEventListener("click", () => {
    window.location.href = "https://www.google.com/";
  });
})();
